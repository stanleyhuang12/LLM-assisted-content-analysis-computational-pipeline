## now comes the real challenge -- use prompting to make GPT do our content analysis

import pandas as pd
from pathlib import Path
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
import json
from pydantic import BaseModel, Field

path_prompt = Path("D:\\my research\\nudge\\prompt")
df = pd.read_csv(path_prompt / 'news_with_code.csv')

# # start with the simple set
df1 = df.loc[(df['Q2_e']=='Yes') & (df['Q2_s']=='Yes') & (df['Q3_e']==1) & (df['Q3_s']==1) & (df['plt']!='tiktok'),:].reset_index(drop=True)

## PLEASE READ 1:
### df is the sample of news you have coded, with four more columns --
### Q2_e: whether Emily thinks the news is included or not
### Q2_s: whether Stanley thinks the news is included or not
### Q3_e: number of distinct changes Emily find
### Q3_s: number of distinct changes Stanley find

## PLEASE READ 2:
### You will use the "text_final" column, which is the total text input in the news release.
### This columns is the main thing that we feed in to GPT for content analyses.
### HOWEVER, the 'text_final' from TikTok contains some incomplete news texts. I am debugging why this is the case
### But for your exploration, you can start with:
### df = df.loc[df['plt']!='tiktok', :].reset_index(drop=True)

## PLEASE READ 3:
# Our goal 1 -- ask GPT to read the news, find how many changes they made that align with the three inclusion criteria we have
# our goal 2 -- for each change, extract all sentences in the news that is related to that change
# This is a hard question. so we need chain-of-thought prompt.

prompt = r"""
Task: You are analyzing a news release to identify digital well-being changes made or proposed by a social media platform. A digital well-being change qualifies if it meets all of these criteria:
I1: The change is clearly associated with digital well-being (e.g., user safety, privacy, harmful content, misinformation, behaviors relevant to well-being, age-appropriate design).
I2: The change involves a product, feature, policy, or the provision of information.
I2: The change involves a product, feature, policy, or the provision of information.
I3: The change is already implemented or scheduled for implementation by the platform.
Your final answer must be in valid JSON with the following structure: 
{{"actions": [
    {{"id": "A1", 
     "summary": "Short description of the first identified action", 
     "criteria_met": ["I1", "I2"] // Example}},
    {{"id": "A2",
     "summary": "Short description of the second identified action",
     "criteria_met": ["I1", "I2", "I3"]// Example}},
     ],
 "evidence": [
    {{"action_id": "A2", // the action that satisfies all I1, I2, and I3
     "text_blocks": ["Full paragraphs or multiple consecutive sentences that describe or elaborate on the action."]}}
     ],
 "count": 1
}}

**Step-by-Step Instructions (Chain of Thought)**
1. Identify Actions
--1.1) Carefully read the entire news release and list each distinct action the platform claims to make that might relate to digital well-being.
--1.2) Assign an ID to each (e.g., A1, A2, …) and provide a short summary describing it.

2. Apply Inclusion Criteria
--2.1) For each identified action, check whether it meets: I1 (digital well-being–relevant), I2 (product/feature/policy/information change), I3 (implemented or scheduled).
--2.2) Record which criteria each action meets (e.g., "criteria_met": ["I1", "I2", "I3"]).

3. Extract Full Contextual Evidence
--3.1) For each action that meets all three criteria (I1 + I2 + I3), locate every relevant paragraph or block of consecutive sentences in the news release that discusses or elaborates on that action.
--3.2) Instead of extracting only a single sentence, copy all closely related text — e.g., the entire paragraph or set of paragraphs/lines describing how the feature works, its motivation, or its effects.
--3.3) Return those blocks verbatim in the "text_blocks" array for the corresponding action.

4. Final JSON Output
Construct a top-level JSON object with:
--4.1) "actions": An array of objects, each having: "id": (e.g., "A1") "summary": (a concise summary of the action) "criteria_met": (list of criteria satisfied; e.g., ["I1", "I2", "I3"])
--4.2) "evidence": An array of objects, each with: "action_id": which action the evidence refers to "text_blocks": an array of verbatim paragraphs or text excerpts that describe or elaborate on the action
--4.3) "count": An integer count of fully qualified actions (i.e., those meeting all three criteria).

Important:
--1) Think through these steps in a chain-of-thought manner, but do not include your intermediate reasoning in the final answer.
--2) Only provide the final JSON (no extra text) when you respond.

"""

prompt = ChatPromptTemplate.from_template(prompt + "News Release to Analyze: {text}")

model = ChatOpenAI(temperature=0,
                   model='gpt-4o',
                   openai_api_key="#### still, change to your own API key ####",
                   )

## now we can formulate thc chain!
llm_chain_1 = prompt | model
request_handle = {'text': df1.loc[1, 'text_final']}
result = llm_chain_1.invoke(request_handle)
 #print(result.content)
  ## clean format of the output
clean_str = result.content.strip("'")
clean_str = clean_str.replace("```json\n", "").replace("\n```", "")
res = json.loads(clean_str)
  ## check read by reading the news: df1.loc[1, 'url']


# We can improve it further: Create a structured output
json_schema = {
    'title': 'identify_changes',
    'description': 'identify number of distinct changes',
  "type": "object",
  "properties": {
    "actions": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "description": "Unique identifier for the action (e.g., A1, A2)."
          },
          "summary": {
            "type": "string",
            "description": "Short description of the identified action."
          },
          "criteria_met": {
            "type": "array",
            "items": {
              "type": "string",
              "enum": ["I1", "I2", "I3"]
            },
            "description": "A list indicating which criteria (I1, I2, I3) the action meets."
          }
        },
        "required": ["id", "summary", "criteria_met"]
      }
    },
    "evidence": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "action_id": {
            "type": "string",
            "description": "The ID of the action that meets all three inclusion criteria I1, I2, and I3."
          },
          "text_blocks": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "description": "Full paragraphs or multiple consecutive sentences elaborating on the action."
          }
        },
        "required": ["action_id", "text_blocks"]
      }
    },
    "count": {
      "type": "integer",
      "description": "The number of actions that meet all three criteria (I1, I2, I3)."
    }
  },
  "required": ["actions", "evidence", "count"]
}

## I update my model with the structured output
structured_llm2 = model.with_structured_output(json_schema)

## I chain my prompt and model together
llm_chain_2 = prompt | structured_llm2

## I invoke the chain
request_handle = {'text': df1.loc[1, 'text_final']}
result2 = llm_chain_2.invoke(request_handle)
print(result2)

## we can see that adding the structured output or not does not affect the two result outputs: res VS result2


## Now let us try the chains with a more complicated case
df2 = df.loc[(df['Q2_e']=='Yes') & (df['Q2_s']=='Yes') & (df['Q3_e']==3) & (df['Q3_s']==3) & (df['plt']!='tiktok'),:].reset_index(drop=True)
result3 = llm_chain_1.invoke({'text': df2.loc[0, 'text_final']})
clean_str3 = result3.content.strip("'")
clean_str3 = clean_str3.replace("```json\n", "").replace("\n```", "")
res3 = json.loads(clean_str3)
res3
result4 = llm_chain_2.invoke({'text': df2.loc[0, 'text_final']})
result4
## again, our models do well! it agrees with you that there are 3 changes.


## now try it in another more complicated case -- a new post from TIKTOK: https://newsroom.tiktok.com/en-eu/new-ways-supporting-parents-helping-teens-build-balanced-digital-habits
tt = '''By Adam Presser, Head of Operations & Trust and Safety
New Family Pairing features give parents additional tools to set boundaries and customizable limits for their individual family needs
A new in-app meditation feature is designed to help teens wind down if they use TikTok after 10pm
Since our Science, Technology, Engineering and Math Feed launched, it is now available in more than 100 countries and is enjoyed by millions of teens every week
Every day, teens around the world express their creativity, connect with friends, and learn on TikTok. We build the strongest safeguards into teen accounts by default to help ensure young people have positive experiences on our app -- and to give parents peace of mind. We see this with the success of #LearnOnTikTok which is igniting new interests in everything from local geology to ancient history. And since launching a feed dedicated to Science, Technology, Engineering and Math (STEM), millions of teens use it every week. Today, we're expanding our family features to provide parents with more options for tailoring their teens' account. We're also introducing a feature to help teens build balanced digital habits.
Simple supervision tools for families
Since launching Family Pairing - TikTok's parenting controls - five years ago, we've continually added new features based on feedback from families, as well as guidance from leading experts. Today, we're enhancing Family Pairing by launching a way for parents to block their teens from being on TikTok during times that they control. No teen or family is the same, and whether it's during family time, school, at night, or a weekend away, caregivers can use our new Time Away feature to decide when it’s best for their teens to take a break. Parents can also set a reoccurring schedule to best suit their family life. If plans change, teens can request extra time, but parents make the final decision.
We're also adding a Family Pairing feature that can allow parents to see who their teen is following on TikTok, and who follows them, along with accounts their teen has blocked. With increased visibility into their teen's network, parents will be better equipped to have ongoing conversations and help their teens develop the digital literacy skills they need.


We also hear that parents want to know more about the content their teens engage with on our app. In response, in the coming months, when a teen reports a video they think may be against TikTok's rules, they can choose to alert a parent, caregiver, or other trusted adult at the same time, even if they aren't using Family Pairing.
With these latest updates, parents can now view or adjust more than 15 safety, well-being, and privacy features. This includes:
Re-enabling our feed dedicated to STEM, if their teen has turned it off. This is now available in more than 100 countries and is enjoyed by millions of teens every week.
Setting customizable daily screen time limits. For example, parents could choose to limit their teens to 30 minutes on TikTok during the week but a little longer on a weekend. Once a parent-set limit has been reached, a teen can only use TikTok if their parent shares a unique passcode. Even if a parent doesn't customize their teen's settings, everyone under 18 has a 60 minute daily screen time limit by default.
Switching their teen's account back to the default private setting, if their teen has made it public.
Helping teens learn balanced digital habits
We're also announcing a new way to encourage young people to switch off at night. If a teen under 16 is on TikTok after 10pm, their For You feed will be interrupted with our new wind down feature. At launch, this is a full-screen takeover with calming music to help teens relax and be mindful of the time. If a teen decides to spend additional time on TikTok after the first reminder, we show a second, harder to dismiss, full-screen prompt. As before, we deliberately do not send push notifications to teens at night, which cannot be changed.
We designed these features to reflect best practices in behavioral change theory by providing positive nudges that can help teens develop balanced long-term habits. In countries where this has already been piloted, the vast majority of teens decide to keep this reminder on. In the coming weeks, we'll also test adding meditation exercises to the wind down reminder, as research shows that mindful meditation can improve sleep quality.


As with any new feature, we look forward to hearing feedback from our community, and to inform our future plans, we're conducting research with parents and teens around the world to understand how else we can help with the development of balanced habits.
Additionally, we've also enlisted the help of TikTok creator, mom, and child safety advocate @danimorin13 to help raise awareness of these new features. Check out her video to hear her thoughts on both the latest updates and existing tools, including Family Pairing. 
Partnering with industry and civil society to build consensus on age assurance
Age assurance is one of the most complex areas that online platforms, policymakers and regulators are grappling with. We continue to enforce our age rules and add additional ways to confirm the age of people who use our platform. As part of our enforcement, we continue to use technology, like machine learning, to prevent people under 13 from being on our platform and make sure that teenagers are in the right age appropriate experience. In addition, we're partnering with Telefónica to understand how people can use age information from their phone provider to confirm their age. TikTok also supports the Multi-Stakeholder Dialogue on Age Assurance, an initiative convened by the Centre for Information Policy Leadership and the WeProtect Global Alliance, that brings together online platforms, regulators, policymakers, privacy and child rights organizations to discuss industry-wide approaches to age assurance.
We constantly work to simplify things for caregivers, so they can feel confident supporting their teens. Our Digital Safety Partnership for Families is designed to make it easier to start conversations about online experiences and set positive digital boundaries together. It's intentionally not specific to any single app or service and includes suggested agreements for when devices and parental supervision tools are used. Throughout 2025, we'll continue to make deliberate decisions to keep TikTok safe, especially for teens.
'''
result5 = llm_chain_2.invoke({'text': tt})
result5
## here, the model starts to over-estimate the number of design changes and provide very little text for each of the change.

## PLEASE READ 4:
### So far, you might feel these are pretty cool and promising. But if you try more and think more, you will find some problems.
### At least from my perspective, I am working on the following tasks. Your task is to also think about how to improve the current prompt (and general workflow).
### I am working on:
#### 1) in a given news, if we identified 2 changes, we want GPT to copy-paste all sentences related to change 1 and change 2, respectively.
#### however, this seems hard for GPT (and even hard for us), because we need to refer which sentences refer to which change.
#### I am thinking if I can use a separate prompt/request to fulfill this goal. Doing so will induce more cost but will improve performance!

#### 2) Thinking about the general workflow, the current prompt may not be functioning in the most efficient way.
#### Both Input text to GPT and ask GPT to output text cost money. Maybe I do not need to "actions" dictionary in the output. I am thinking about better ways to simplify the whole workflow.

#### 3) Continue designing for the rest of the workflow and prompts!

## [again, you are invited to think about how to solve these problems]

