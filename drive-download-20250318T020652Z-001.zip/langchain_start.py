## it turns out we can do same thing that we do in open_ai_start script (where we use the openai package directly) in langchain
## langchain has many advantages, ie, it is a more general coding framework for all sorts of LLMs, so we can actually try different model configs.

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

## I define the LLM I want to use
model = ChatOpenAI(temperature=0,
                   model='gpt-4o',
                   openai_api_key="#### still, change to your own API key ####",
                   )#"gpt-4o")

## I first defined my user prompt
user_prompt = f"Identify whether the given sentence below contains each kind of motivation. " \
              f"Motivation 1: using social media to entertain, have fun, or relax.\n" \
                               f"For example, sentences below contain motivation of using social media to entertain, have fun, or relax. \n" \
                               "example 1: Scrolling for entertainment. \n"\
                               "example 2: Basically i use it for fun. \n"\
                               "example 3: To enjoy watching funny videos. \n"\
                               "example 4: Mainly for entertainment purposes and also learning through watching some tuitorials. \n"\
                               "example 5: it is very interesting. \n" \
                               "example 6: I have found a moment of downtime and decided to use it as some mild entertainment\n" \
              f"Motivation 2: using social media to pass time\n" \
                      f"For example, sentences below contain motivation of using social media to pass time.\n" \
                      "example 1: i want to kill time. \n" \
                      "example 2: To cure boredom. \n" \
              f"Motivation 3: use social media to cope with negative things\n" \
                f"For example, sentences below contain motivation of using social media to cope with negative things\n" \
                               "example 1: I have found a moment of downtime and decided to use it as some mild entertainment\n" \
                                "example 2: To distract myself\n" \
                                "example 3: I have used it because it is an addictive force of habit and helps me forget about things.\n" \
              f"Motivation 4: use social media as a habit\n" \
              f"For example, sentences below contain motivation of using social media as a habit\n" \
              "example 1: I have used it because it is an addictive force of habit and helps me forget about things.'\n" \
              "example 2: just a habit\n" \
              "Now, please identify whether the given sentence below contains motivation of using social media to 1) entertain, have fun, or relax, " \
              "2) pass time, and 3) cope with negative things, and 4) as a habit\n"\
                               "Please only answer Yes or No for each motivation and return your answer in json format.\n"

prompt = ChatPromptTemplate.from_template(user_prompt + "The given sentence: {text}")

# Create a structured output of my LLM so it will not output things I do not need, here I define a class with 4 different fields
class mot(BaseModel):
    m1: str = Field(description="Whether the sentence contains motivation of using social media to entertain, have fun, or relax")
    m2: str = Field(description="Whether the sentence contains motivation of using social media to pass time")
    m3: str = Field(description="Whether the sentence contains motivation of using social media to cope with negative things")
    m4: str = Field(description="Whether the sentence contains motivation of using social media as a habit")

## I update my model with the structured output
structured_llm2 = model.with_structured_output(mot.model_json_schema())#, #method="json_mode")

## I chain my prompt and model together
mot_chain = prompt | structured_llm2

## I invoke the chain
request_handle = {'text': 'I use social media because I am a anxious PHD student that try to relax after a stressful meeting and I also want to use it for dating'}
result = mot_chain.invoke(request_handle)

## check your results
print(result)
  ## {'m1': 'Yes', 'm2': 'No', 'm3': 'Yes', 'm4': 'No'}