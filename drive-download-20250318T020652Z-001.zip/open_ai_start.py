##### this script gives a simple example for prompting things with OPENAI
from openai import OpenAI

client = OpenAI(
    api_key="#### replace with your own api key ####",
)

# try your prompt!
text = 'i do not knwo, just kill time'
chat_completion = client.beta.chat.completions.parse(
   messages=[
      {
         "role": "system",
         "content": "You are a helpful research assistant tasked with identifying whether people are aware of their motivations for"
                    "using social media based on sentences they write in response to an open-ended question in a survey."
      },
      {
         "role": "user",
         "content": f"In this exercise, you will identify whether the motivation of using social media is 'clear', 'not clear', or 'just a habit' in the given sentence."
                    f"Please see several examples of sentences from users and the level of motivation awareness below \n"
                    "sentence 1: check cryptocurrency news -- motivation awareness 1: clear \n"
                    "sentence 2: scrolling for news -- motivation awareness 2: not clear \n"
                    "sentence 3: I was bored. It's a habit.. -- motivation awareness 3: just a habit \n"
                    "Now, please identify whether the motivation is 'clear' or 'not clear' or 'just a habit' in the given sentences below. \n"
                    "Please only reply with one of the three options: 'clear' or 'not clear' or 'just habit', and do not return other text.\n"
                    f"{text}"

      },
   ],
   model="gpt-4o-2024-08-06",
   n=1,
   temperature=0, ## higher temparature means more creative the output is --keep as 0 for reliability

)

trans_text = chat_completion.choices[0].message.content


## check its output
print(trans_text)